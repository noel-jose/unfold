<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Unf01d" />
        <meta name="author" content="WEBTEAM CEC" />
        <title>Question <?php echo e($question->questionNo); ?></title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="question/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
    </head>
    <body id="page-top">
        
        <section class="page-section" id="contact">
            <?php if(!$question->showAnswer): ?>
            <!-- counter code -->
            <div class="counter">
                <h4>Time left : </h4>
                <ul id="demo">
                    <li class="d-flex flex-column"><span class="circle hours"></span><span>Hours</span></li>
                    <li class="d-flex flex-column"><span class="circle minutes"></span><span>Minutes</span></li>
                    <li class="d-flex flex-column"><span class="circle seconds"></span><span>Seconds</span></li>
                </ul>
            </div>
            <?php endif; ?>
            <div class="container">
                <div class="text-center">
                    <div class="question m-3">
                        <h2 class="mb-4">Question <?php echo e($question->questionNo); ?></h2>
                        <?php echo $question->question; ?>

                    </div>
                    <?php if($question->hasHint): ?>
                    <div class="hint m-3">
                        <h2 class="m-4">Hint</h2>
                        <?php echo $question->hint; ?>

                    </div>
                    <?php endif; ?>
                </div>
                <?php if(!$question->showAnswer): ?>
                <div class="form mt-5">
                <form id="contactForm" action="<?php echo e(route('question.submit',$question)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-12">
                            <div class="form-group">
                                <!-- Name input-->
                                <input class="form-control" name = "name" id="name" type="text" placeholder="Your Name "/>
                            </div>
                            <div class="form-group">
                                <!-- Email address input-->
                                <input class="form-control" name = "ieeeid" id="ieeeid" type="number" placeholder="Your IEEE membership ID" />
                            </div>
                            <div class="form-group mb-md-0">
                                <!-- Phone number input-->
                                <input class="form-control" name = "answer" id="answer" type="text" placeholder="Your Answer"/>
                            </div>
                        </div>
                    </div>
                    <!-- Submit Button-->
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase" id="submitButton" type="submit">Submit</button></div>
                </form>
                </div>
                <?php else: ?>
                <div class="answer text-center m-3">
                    <h2 class="m-4">Answer</h2>
                    <?php echo $question->answer; ?>

                </div>
                <?php endif; ?>
            </div>
        </section>
        <div id="endtime" style="display: none;"><?php echo e($question->endTime); ?></div>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <?php if(!$question->showAnswer): ?>
        <script src="<?php echo e(asset('js/counter.js')); ?>"></script>
        <?php endif; ?>
    </body>
</html>


<?php /**PATH F:\server\htdocs\Laravel\unfold\resources\views/question.blade.php ENDPATH**/ ?>