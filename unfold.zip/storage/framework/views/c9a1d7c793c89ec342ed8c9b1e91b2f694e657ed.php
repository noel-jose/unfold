<ul>
<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($question->showQuestion): ?>
        <li><?php echo e($question->question); ?></li>
        <?php if($question->hasHint): ?>
            <p><?php echo e($question->hint); ?></p>
        <?php endif; ?>
        <?php if($question->showAnswer): ?>
            <p><?php echo e($question->answer); ?></p>
        <?php endif; ?>
    <?php else: ?>
        <li>Cant show this list</li>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH F:\server\htdocs\Laravel\unfold\resources\views/sample.blade.php ENDPATH**/ ?>